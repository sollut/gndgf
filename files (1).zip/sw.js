/* Service Worker — Недельный Планер
   Кэширует оболочку приложения (index.html, manifest.json, иконки,
   шрифт Google Fonts), чтобы приложение открывалось без сети после
   первого онлайн-визита. Вся логика и данные планера живут в
   localStorage на странице — этот файл НЕ хранит и не видит данных
   пользователя, только статические файлы для оффлайн-доступа.

   Поднимайте CACHE_VERSION при каждом значимом обновлении index.html,
   чтобы у пользователей подтянулась свежая версия вместо кэша. */

var CACHE_VERSION = "weekly-planner-v1";

var APP_SHELL = [
  "./index.html",
  "./manifest.json",
  "./icon-192.png",
  "./icon-512.png",
  "./icon-192-maskable.png",
  "./icon-512-maskable.png",
  "./apple-touch-icon.png"
];

self.addEventListener("install", function(event){
  event.waitUntil(
    caches.open(CACHE_VERSION).then(function(cache){
      // addAll должен быть атомарным — если хотя бы один файл 404,
      // откатываем всю установку, поэтому ключевой index.html идёт
      // первым и отдельно, остальное — best-effort
      return cache.add("./index.html").then(function(){
        return Promise.all(
          APP_SHELL.slice(1).map(function(url){
            return cache.add(url).catch(function(){
              // иконка могла не лежать рядом — не валим установку целиком
            });
          })
        );
      });
    })
  );
  self.skipWaiting();
});

self.addEventListener("activate", function(event){
  event.waitUntil(
    caches.keys().then(function(keys){
      return Promise.all(
        keys
          .filter(function(key){ return key !== CACHE_VERSION; })
          .map(function(key){ return caches.delete(key); })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener("fetch", function(event){
  var req = event.request;
  if(req.method !== "GET") return;

  var url = new URL(req.url);
  var isFontHost = url.hostname === "fonts.googleapis.com" || url.hostname === "fonts.gstatic.com";

  if(isFontHost){
    // шрифты меняются редко — stale-while-revalidate: сразу отдаём
    // из кэша, если есть, и в фоне обновляем
    event.respondWith(
      caches.open(CACHE_VERSION).then(function(cache){
        return cache.match(req).then(function(cached){
          var networkFetch = fetch(req).then(function(res){
            cache.put(req, res.clone());
            return res;
          }).catch(function(){ return cached; });
          return cached || networkFetch;
        });
      })
    );
    return;
  }

  if(url.origin === self.location.origin){
    // оболочка приложения — cache-first с фоновым обновлением
    event.respondWith(
      caches.match(req).then(function(cached){
        var networkFetch = fetch(req).then(function(res){
          if(res && res.ok){
            caches.open(CACHE_VERSION).then(function(cache){ cache.put(req, res.clone()); });
          }
          return res;
        }).catch(function(){
          // нет сети: для навигационных запросов отдаём закэшированный index.html,
          // чтобы приложение открылось даже если точный URL не совпал
          if(req.mode === "navigate"){ return caches.match("./index.html"); }
          return cached;
        });
        return cached || networkFetch;
      })
    );
  }
});
